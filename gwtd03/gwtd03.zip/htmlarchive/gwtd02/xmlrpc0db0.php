<br />
<b>Parse error</b>:  syntax error, unexpected 'version' (T_STRING) in <b>/home/wptransl/public_html/htmlarchive/gwtd02/xmlrpc0db0.php</b> on line <b>1</b><br />
